package ejemploMapa;

public class Jugador {

}
